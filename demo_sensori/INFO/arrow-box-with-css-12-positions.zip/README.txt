A Pen created at CodePen.io. You can find this one at https://codepen.io/ewayma/pen/iFLeb.

 Styles created using Stylus  to create arrows attached to the centers, as well as the edges of a box. Total of 12 positions are provided.