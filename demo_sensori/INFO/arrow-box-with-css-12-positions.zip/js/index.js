var CLASS_NAME_LOOKUP = {
  "bottom center": "",
  "bottom left": "arrow-bottom-left",
  "bottom right": "arrow-bottom-right",
  "top center": "arrow-top-center",
  "top left": "arrow-top-left",
  "top right": "arrow-top-right",
  "left center": "arrow-left-center",
  "left top": "arrow-left-top",
  "left bottom": "arrow-left-bottom",
  "right center": "arrow-right-center",
  "right top": "arrow-right-top",
  "right bottom": "arrow-right-bottom"
};

var BOX_BG_CLASS = ["blue", "green", "orange", "red"];

(function (){
  var targetNode = document.getElementById("boxContainer");
  var boxesHTML = "";
  var classNames = "";
  var i = 0;
  
  for(var pos in CLASS_NAME_LOOKUP){
    classNames = "box " + BOX_BG_CLASS[Math.floor(i / 3)];
    classNames += " " + CLASS_NAME_LOOKUP[pos];
    //var div = document.createElement("div");
    var div = "<div class='" + classNames + "'></div>"; 
    boxesHTML += div; 
    ++i;
  }   
  
  targetNode.innerHTML = boxesHTML;
})();