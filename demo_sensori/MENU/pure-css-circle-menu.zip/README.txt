A Pen created at CodePen.io. You can find this one at https://codepen.io/hadarweiss/pen/WvEXeK.

 Circular menu with toggle button created only with css. You can configure the menu size, number of items, color of toggle button and links icons.