A Pen created at CodePen.io. You can find this one at https://codepen.io/ettrics/pen/jERWPP.

 An interactive bar graph packed with animations and information. Built with CSS and jQuery.